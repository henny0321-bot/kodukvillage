/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from "motion/react";
import { 
  Instagram, 
  Youtube, 
  Mail, 
  ArrowUpRight, 
  Menu, 
  X, 
  Sparkles,
  User,
  ExternalLink,
  Send
} from "lucide-react";
import React, { useState } from "react";

// Types
interface Creator {
  id: number;
  name: string;
  role: string;
  specialty: string;
  bio: string;
  image: string;
  socials: {
    instagram?: string;
    youtube?: string;
    threads?: string;
    tiktok?: string;
  };
  socialLinks?: {
    instagram?: string;
    youtube?: string;
    threads?: string;
    tiktok?: string;
  };
  keywords: string[];
  collaborationCondition: string;
  password?: string;
}

const ADMIN_MASTER_PASSWORD = "0321";

interface PortfolioItem {
  id: number;
  title: string;
  category: string;
  image?: string;
  date?: string;
  color: string;
}

// Data
const INITIAL_CREATORS: Creator[] = [
  { 
    id: 1, 
    name: "헤니 (Henny)", 
    role: "무해한 귀여움 추구", 
    specialty: "큐트 & 데일리 메이크업", 
    bio: "무해하게 귀여운 매력을 발견하는 코덕마을의 분위기 메이커입니다.",
    image: "/src/assets/images/creator_henny_1779182632424.png",
    socials: { instagram: "@henny_beauty", youtube: "Henny Beauty" },
    socialLinks: { instagram: "https://instagram.com", youtube: "https://youtube.com" },
    keywords: ["#무해함", "#큐트", "#데일리컬러"],
    collaborationCondition: "장기 브랜드 파트너십을 선호합니다.",
    password: "admin",
    isApproved: true
  },
  { 
    id: 2, 
    name: "지혜 (Jihye)", 
    role: "다재다능 크리에이터", 
    specialty: "올라운드 디렉팅 & 정보 공유", 
    bio: "기획, 촬영, 편집까지 모든 걸 완벽하게 해내는 마을의 능력자입니다.",
    image: "/src/assets/images/creator_jihye_1779182648065.png",
    socials: { instagram: "@jihye_official", tiktok: "@jihye_creative" },
    socialLinks: { instagram: "https://instagram.com", tiktok: "https://tiktok.com" },
    keywords: ["#올라운더", "#영상천재", "#다재다능"],
    collaborationCondition: "크리에이티브한 가이드라인을 존중합니다.",
    password: "admin",
    isApproved: true
  },
  { 
    id: 3, 
    name: "명랑 (Myungrang)", 
    role: "공구장인", 
    specialty: "깐깐한 큐레이션 & 완판 마법", 
    bio: "직접 써보고 검증된 보석 같은 아이템만 골라오는 마을의 공구 전문가입니다.",
    image: "/src/assets/images/creator_myungrang_2_1779182672731.png",
    socials: { instagram: "@myungrang_pick", threads: "@myung_archive" },
    socialLinks: { instagram: "https://instagram.com", threads: "https://threads.net" },
    keywords: ["#공구장인", "#완판신화", "#깐깐한검증"],
    collaborationCondition: "최소 2주 이상의 직접 사용 기간이 필요합니다.",
    password: "admin",
    isApproved: true
  },
];

const portfolio: PortfolioItem[] = [
  { 
    id: 1, 
    title: "코덕마을 입주 가이드", 
    category: "Info", 
    products: ["마을 가이드북", "환영 패키지"], 
    tutorialUrl: "#",
    color: "#FFE4E1"
  },
  { 
    id: 2, 
    title: "이달의 추천 브랜드", 
    category: "Brand", 
    products: ["뷰티 브랜드 A", "스킨케어 브랜드 B"], 
    tutorialUrl: "#",
    color: "#E0F2F1"
  },
  { 
    id: 3, 
    title: "공구 일정 캘린더", 
    category: "Schedule", 
    products: ["3월 공구 목록"], 
    tutorialUrl: "#",
    color: "#FFF3E0"
  },
];

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedWork, setSelectedWork] = useState<PortfolioItem | null>(null);
  const [formState, setFormState] = useState({ name: "", email: "", company: "", content: "" });
  
  // Resident Management States
  const [creators, setCreators] = useState<Creator[]>(INITIAL_CREATORS);
  const [portfolioItems, setPortfolioItems] = useState<PortfolioItem[]>(portfolio);
  const [isAddPortfolioModalOpen, setIsAddPortfolioModalOpen] = useState(false);
  const [newPortfolio, setNewPortfolio] = useState<Partial<PortfolioItem>>({
    title: "",
    category: "Event",
    image: "",
    date: new Date().toISOString().split('T')[0],
    color: "#FFE4E1"
  });
  const [isAddResidentModalOpen, setIsAddResidentModalOpen] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [newResident, setNewResident] = useState<Partial<Creator>>({
    name: "",
    role: "",
    specialty: "",
    bio: "",
    image: "",
    keywords: [],
    collaborationCondition: "",
    password: "",
    socials: {},
    socialLinks: {},
    isApproved: false
  });
  
  // Verification Modal State
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState(false);
  const [verifyTargetId, setVerifyTargetId] = useState<number | null>(null);
  const [verifyPassword, setVerifyPassword] = useState("");
  const [verifyAction, setVerifyAction] = useState<"delete" | "edit" | "admin" | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`[코덕마을 문의] ${formState.name}님의 제안`);
    const body = encodeURIComponent(
      `성함: ${formState.name}\n` +
      `이메일: ${formState.email}\n` +
      `소속/회사: ${formState.company}\n\n` +
      `문의 내용:\n${formState.content}`
    );
    window.location.href = `mailto:henny0321@naver.com?subject=${subject}&body=${body}`;
    setFormState({ name: "", email: "", company: "", content: "" });
  };

  const handleAddResident = (e: React.FormEvent) => {
    e.preventDefault();
    const creator: Creator = {
      id: Date.now(),
      name: newResident.name || "새 주민",
      role: newResident.role || "크리에이터",
      specialty: newResident.specialty || "뷰티",
      bio: newResident.bio || "반갑습니다!",
      image: newResident.image || "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?auto=format&fit=crop&q=80&w=800",
      socials: newResident.socials || {},
      socialLinks: newResident.socialLinks || {},
      keywords: newResident.keywords || [],
      collaborationCondition: newResident.collaborationCondition || "협업 가능합니다.",
      password: newResident.password || "1234",
      isApproved: false
    };
    
    setCreators([...creators, creator]);
    setIsAddResidentModalOpen(false);
    setNewResident({
      name: "",
      role: "",
      specialty: "",
      bio: "",
      image: "",
      keywords: [],
      collaborationCondition: "",
      password: "",
      socials: {},
      socialLinks: {},
      isApproved: false
    });
    alert("입주 신청이 완료되었습니다! 🎉\n관리자의 승인 후 마을 페이지에 표시됩니다.");
  };

  const handleDeleteRequest = (id: number) => {
    setVerifyTargetId(id);
    setVerifyAction("delete");
    setVerifyPassword("");
    setIsVerifyModalOpen(true);
  };

  const toggleAdminMode = () => {
    if (isAdminMode) {
      setIsAdminMode(false);
    } else {
      setVerifyAction("admin");
      setVerifyPassword("");
      setIsVerifyModalOpen(true);
    }
  };

  const handleApprove = (id: number) => {
    setCreators(creators.map(c => c.id === id ? { ...c, isApproved: true } : c));
    alert("주민 입주가 승인되었습니다! ✨");
  };

  const handlePortfolioSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const item: PortfolioItem = {
      id: Date.now(),
      title: newPortfolio.title || "새로운 기록",
      category: newPortfolio.category || "기타",
      image: newPortfolio.image,
      date: newPortfolio.date,
      color: newPortfolio.color || "#FFE4E1",
    };
    
    setPortfolioItems([item, ...portfolioItems]);
    setIsAddPortfolioModalOpen(false);
    setNewPortfolio({
      title: "",
      category: "Event",
      image: "",
      date: new Date().toISOString().split('T')[0],
      color: "#FFE4E1"
    });
    alert("새로운 기록이 보관되었습니다! 📚");
  };

  const handlePortfolioImage = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setNewPortfolio({ ...newPortfolio, image: e.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePortfolioPaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData.items;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        const file = items[i].getAsFile();
        if (file) handlePortfolioImage(file);
      }
    }
  };
  const handleVerifyPassword = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (verifyAction === "admin") {
      if (verifyPassword === ADMIN_MASTER_PASSWORD) {
        setIsAdminMode(true);
        setIsVerifyModalOpen(false);
        setVerifyPassword("");
      } else {
        alert("관리자 비밀번호가 일치하지 않습니다.");
      }
      return;
    }

    const target = creators.find(c => c.id === verifyTargetId);
    if (!target) return;

    if (verifyPassword === target.password || verifyPassword === ADMIN_MASTER_PASSWORD) {
      if (verifyAction === "delete") {
        setCreators(creators.filter(c => c.id !== verifyTargetId));
        alert("주민 정보가 삭제되었습니다.");
      }
      setIsVerifyModalOpen(false);
      setVerifyTargetId(null);
      setVerifyAction(null);
    } else {
      alert("비밀번호가 일치하지 않습니다. 관리자 혹은 본인만 가능합니다.");
    }
  };

  const handleImageFile = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setNewResident({ ...newResident, image: e.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData.items;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        const file = items[i].getAsFile();
        if (file) handleImageFile(file);
      }
    }
  };

  return (
    <div className="min-h-screen bg-brand-cream text-brand-dark font-sans selection:bg-brand-accent selection:text-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 w-full z-50 px-8 py-6 flex justify-between items-center bg-brand-cream/80 backdrop-blur-md border-b border-brand-dark/5">
        <div className="text-2xl font-serif font-bold tracking-tighter">코덕마을</div>
        
        <div className="hidden md:flex gap-10 text-sm font-bold">
          <a href="#creators" className="hover:text-brand-accent transition-colors">코덕마을 주민들</a>
          <a href="#gallery" className="hover:text-brand-accent transition-colors">기록실</a>
          <a href="#contact" className="hover:text-brand-accent transition-colors">문의하기</a>
        </div>

        <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden">
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "100%" }}
            className="fixed inset-0 bg-brand-dark z-40 flex flex-col items-center justify-center gap-8 text-brand-cream"
          >
            <a href="#creators" onClick={() => setIsMenuOpen(false)} className="text-4xl font-serif">Creators</a>
            <a href="#gallery" onClick={() => setIsMenuOpen(false)} className="text-4xl font-serif">Portfolio</a>
            <a href="#contact" onClick={() => setIsMenuOpen(false)} className="text-4xl font-serif">Inquiry</a>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <header className="h-[80vh] flex flex-col items-center justify-center text-center px-8 relative overflow-hidden">
        <motion.div
          animate={{ scale: [1, 1.05, 1], rotate: [0, 1, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--color-brand-peach)_0%,_transparent_70%)] opacity-30 pointer-events-none"
        />
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="z-10"
        >
          <div className="flex items-center justify-center gap-2 mb-6">
            <Sparkles size={20} className="text-brand-accent animate-pulse" />
            <span className="text-sm font-bold opacity-60 font-cute">✨ 코덕들을 위한 비밀 기지 ✨</span>
          </div>
          <h1 className="text-6xl md:text-8xl font-serif mb-8 tracking-tight">
            코덕마을에 오신 걸 <br />
            <span className="font-cute text-5xl md:text-9xl text-brand-accent block mt-4 animate-bounce-slow">환영합니다!</span>
          </h1>
          <p className="max-w-xl mx-auto text-lg md:text-xl font-light text-brand-dark/60 leading-relaxed">
            아름다운 모든 것을 사랑하는 <br />
            뷰티 크리에이터 마을입니다.
          </p>
        </motion.div>
      </header>

      {/* Village Residents Section */}
      <section id="creators" className="py-32 px-8 bg-brand-white">
        <div className="max-w-7xl mx-auto px-4 md:px-0">
          <div className="mb-20 text-center relative">
            <h2 className="text-5xl md:text-7xl font-serif mb-6">코덕마을 주민들</h2>
            <p className="text-brand-dark/40 text-sm font-bold font-cute">우리 마을의 멋진 크리에이터들을 소개할게요!</p>
            
            <div className="mt-8 flex justify-center">
              {/* Resident Add Button */}
              <button 
                onClick={() => setIsAddResidentModalOpen(true)}
                className="px-6 py-3 bg-brand-dark text-brand-cream rounded-full text-xs font-bold hover:bg-brand-accent transition-all animate-bounce-slow"
              >
                + 입주 신청하기
              </button>
            </div>

            {isAdminMode && (
              <div className="mt-4 inline-block px-4 py-1.5 bg-brand-accent/10 text-brand-accent text-[10px] font-bold rounded-full border border-brand-accent/20">
                승인 대기 중인 주민을 확인하고 승인하거나 삭제할 수 있습니다.
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {creators
              .filter(creator => isAdminMode || creator.isApproved)
              .map((creator) => (
              <motion.div
                key={creator.id}
                whileHover={{ y: -5 }}
                className={`group flex flex-col md:flex-row border rounded-[3rem] overflow-hidden transition-all hover:shadow-xl ${
                  !creator.isApproved 
                    ? "border-brand-accent border-dashed bg-brand-accent/5" 
                    : "border-brand-dark/5 bg-brand-cream/30"
                }`}
              >
                {/* Left Side: Photo */}
                <div className="w-full md:w-2/5 aspect-[3/4] md:aspect-auto overflow-hidden relative grayscale group-hover:grayscale-0 transition-all duration-700">
                  <img src={creator.image} alt={creator.name} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-dark/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  
                  {!creator.isApproved && (
                    <div className="absolute inset-0 bg-brand-accent/20 flex items-center justify-center backdrop-blur-[2px]">
                      <span className="bg-brand-accent text-white px-4 py-1.5 rounded-full text-[10px] font-bold shadow-lg">
                        승인 대기 중
                      </span>
                    </div>
                  )}
                </div>

                {/* Right Side: Details */}
                <div className="flex-1 p-8 md:p-10 flex flex-col justify-between relative bg-white/50">
                  {/* Delete Button */}
                  <button 
                    onClick={() => handleDeleteRequest(creator.id)}
                    className="absolute top-8 left-8 text-brand-dark/20 hover:text-red-400 transition-colors z-10"
                    title="주민 삭제하기"
                  >
                    <X size={16} />
                  </button>

                  {/* Approve Button (Admin Only) */}
                  {isAdminMode && !creator.isApproved && (
                    <button 
                      onClick={() => handleApprove(creator.id)}
                      className="absolute bottom-32 right-10 px-4 py-2 bg-brand-accent text-white rounded-full text-[10px] font-bold shadow-lg hover:scale-105 transition-transform z-10"
                    >
                      승인 완료하기 ✨
                    </button>
                  )}
                  {/* Decorative QR-like tag */}
                  <div className="absolute top-8 right-8 w-10 h-10 border border-brand-dark/10 p-1.5 opacity-40 group-hover:opacity-100 transition-opacity">
                    <div className="grid grid-cols-3 gap-0.5 h-full w-full">
                      {Array(9).fill(0).map((_, i) => (
                        <div key={i} className={`bg-brand-dark ${Math.random() > 0.4 ? 'opacity-100' : 'opacity-20'}`} />
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-lg font-cute mb-1 text-brand-accent">{creator.role}</div>
                    <h3 className="text-4xl mb-4 font-serif">{creator.name}</h3>
                    
                    <div className="flex flex-wrap gap-2 mb-6">
                      {creator.keywords.map((kw, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-brand-dark/5 text-[10px] font-bold rounded-full">
                          {kw}
                        </span>
                      ))}
                    </div>

                    <p className="text-brand-dark/50 leading-relaxed text-sm mb-6 line-clamp-2 md:line-clamp-3">{creator.bio}</p>
                    
                    <div className="mb-6 p-4 bg-brand-peach/15 rounded-2xl border border-brand-peach/20">
                      <div className="text-[10px] font-bold opacity-40 uppercase mb-1">협업 조건</div>
                      <div className="text-[11px] font-bold leading-tight">{creator.collaborationCondition}</div>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-4 items-center mt-auto border-t border-brand-dark/5 pt-4">
                    {creator.socials.instagram && (
                      <a 
                        href={creator.socialLinks?.instagram || "#"} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-[10px] font-bold hover:text-brand-accent cursor-pointer transition-colors"
                      >
                        <Instagram size={14} /> <span className="opacity-60">{creator.socials.instagram}</span>
                      </a>
                    )}
                    {creator.socials.youtube && (
                      <a 
                        href={creator.socialLinks?.youtube || "#"} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-[10px] font-bold hover:text-brand-accent cursor-pointer transition-colors"
                      >
                        <Youtube size={14} /> <span className="opacity-60 text-[9px]">YouTube</span>
                      </a>
                    )}
                    {creator.socials.tiktok && (
                      <a 
                        href={creator.socialLinks?.tiktok || "#"} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-[10px] font-bold hover:text-brand-accent cursor-pointer transition-colors"
                      >
                        <span className="text-[10px] font-serif font-black underline italic">TikTok</span>
                      </a>
                    )}
                    {creator.socials.threads && (
                      <a 
                        href={creator.socialLinks?.threads || "#"} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-[10px] font-bold hover:text-brand-accent cursor-pointer transition-colors"
                      >
                        <span className="text-[10px] font-serif font-black underline italic">Threads</span>
                      </a>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Recording Room Gallery Section */}
      <section id="gallery" className="py-32 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-20">
            <h2 className="text-5xl md:text-7xl font-serif tracking-tighter">기록실</h2>
            <div className="flex flex-col items-end gap-4">
              <div className="text-sm text-brand-dark/40 font-bold font-cute">코덕마을의 다양한 활동 정보를 확인할 수 있어요!</div>
              {isAdminMode && (
                <button 
                  onClick={() => setIsAddPortfolioModalOpen(true)}
                  className="px-6 py-2.5 bg-brand-accent text-white rounded-full text-[10px] font-bold hover:bg-brand-dark transition-all shadow-lg"
                >
                  + 새로운 기록 남기기
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {portfolioItems.length > 0 ? (
              portfolioItems.map((item) => (
                <motion.div
                  key={item.id}
                  layoutId={`card-${item.id}`}
                  onClick={() => setSelectedWork(item)}
                  className="cursor-pointer bg-white border border-brand-dark/5 rounded-3xl overflow-hidden group"
                >
                  <div 
                    className="aspect-square w-full relative flex items-center justify-center overflow-hidden"
                    style={{ backgroundColor: !item.image ? item.color : 'transparent' }}
                  >
                    {item.image ? (
                      <img src={item.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={item.title} />
                    ) : (
                      <motion.div className="text-4xl opacity-20 font-serif italic select-none group-hover:scale-125 transition-transform duration-700">
                        KODUK
                      </motion.div>
                    )}
                    <div className="absolute inset-0 bg-brand-dark/0 group-hover:bg-brand-dark/5 transition-colors" />
                    <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ArrowUpRight size={24} />
                    </div>
                  </div>
                  <div className="p-8">
                    <div className="flex justify-between items-start mb-2">
                      <div className="text-[10px] mb-2 opacity-40">{item.category}</div>
                      <div className="text-[9px] opacity-30 font-mono italic">{item.date}</div>
                    </div>
                    <h3 className="text-xl font-serif">{item.title}</h3>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full py-20 text-center border-2 border-dashed border-brand-dark/5 rounded-[3rem] opacity-40">
                <p className="text-xl font-cute">곧 멋진 기록들이 가득 채워질 예정이에요! ✨</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Portfolio Detail Modal */}
      <AnimatePresence>
        {selectedWork && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedWork(null)}
              className="fixed inset-0 bg-brand-dark/40 backdrop-blur-sm z-[60]"
            />
            <motion.div
              layoutId={`card-${selectedWork.id}`}
              className="fixed inset-4 md:inset-x-[30%] md:inset-y-[20%] bg-brand-white z-[70] rounded-[3rem] overflow-hidden shadow-2xl flex flex-col"
            >
              <div 
                className="w-full h-2/3 flex items-center justify-center overflow-hidden relative"
                style={{ backgroundColor: !selectedWork.image ? selectedWork.color : 'transparent' }}
              >
                {selectedWork.image ? (
                  <img src={selectedWork.image} className="w-full h-full object-cover" alt={selectedWork.title} />
                ) : (
                  <div className="text-8xl md:text-[200px] font-serif italic text-brand-dark opacity-5 leading-none select-none">
                    K
                  </div>
                )}
                <button 
                  onClick={() => setSelectedWork(null)}
                  className="absolute top-8 right-8 p-2 bg-white/20 backdrop-blur-md rounded-full transition-colors text-brand-dark"
                >
                  <X size={24} />
                </button>
              </div>
              <div className="flex-1 p-10 overflow-y-auto">
                <div className="flex justify-between items-start mb-4">
                  <div className="text-sm text-brand-accent font-bold font-cute">{selectedWork.category}</div>
                  <div className="text-[10px] opacity-40 font-mono italic">{selectedWork.date}</div>
                </div>
                <h3 className="text-4xl font-serif">{selectedWork.title}</h3>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
      
      {/* Add Portfolio Record Modal */}
      <AnimatePresence>
        {isAddPortfolioModalOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddPortfolioModalOpen(false)}
              className="fixed inset-0 bg-brand-dark/40 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 h-full w-full max-w-xl bg-brand-cream z-50 p-12 overflow-y-auto shadow-2xl"
            >
              <div className="flex justify-between items-center mb-12">
                <div>
                  <h2 className="text-4xl font-serif mb-2">기록 업데이트하기</h2>
                  <p className="text-xs opacity-40 font-cute">마을의 소중한 순간을 영구 보관합니다.</p>
                </div>
                <button onClick={() => setIsAddPortfolioModalOpen(false)} className="hover:rotate-90 transition-transform">
                  <X size={32} />
                </button>
              </div>

              <form onSubmit={handlePortfolioSubmit} className="space-y-12">
                <div className="space-y-4">
                  <label className="text-xs font-bold opacity-40 font-cute">기록 사진 (업로드 또는 붙여넣기)</label>
                  <div 
                    onPaste={handlePortfolioPaste}
                    className="relative w-full aspect-video border-2 border-dashed border-brand-dark/10 rounded-3xl flex flex-col items-center justify-center gap-4 bg-white/50 group overflow-hidden"
                  >
                    {newPortfolio.image ? (
                      <>
                        <img src={newPortfolio.image} className="w-full h-full object-cover" alt="Preview" />
                        <button 
                          type="button"
                          onClick={() => setNewPortfolio({...newPortfolio, image: ""})}
                          className="absolute top-4 right-4 bg-brand-dark text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={16} />
                        </button>
                      </>
                    ) : (
                      <div className="text-center p-8">
                        <div className="mb-4 text-brand-dark/20 flex justify-center">
                          <span className="material-symbols-outlined text-4xl">Add_Photo_Alternate</span>
                        </div>
                        <p className="text-xs font-bold mb-4 opacity-40 leading-relaxed font-cute">
                          현장 사진을 선택하거나 붙여넣어주세요!
                        </p>
                        <input 
                          type="file" 
                          accept="image/*"
                          onChange={(e) => e.target.files && handlePortfolioImage(e.target.files[0])}
                          className="hidden" 
                          id="portfolio-image-upload"
                        />
                        <label 
                          htmlFor="portfolio-image-upload"
                          className="px-6 py-2 bg-brand-dark text-brand-cream text-[10px] font-bold rounded-full cursor-pointer hover:bg-brand-accent transition-colors"
                        >
                          이미지 선택
                        </label>
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-xs font-bold opacity-40 font-cute">제목</label>
                    <input 
                      required
                      type="text" 
                      placeholder="기록의 제목을 입력해주세요"
                      className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                      value={newPortfolio.title}
                      onChange={(e) => setNewPortfolio({...newPortfolio, title: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold opacity-40 font-cute">기록 날짜</label>
                    <input 
                      required
                      type="date" 
                      className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                      value={newPortfolio.date}
                      onChange={(e) => setNewPortfolio({...newPortfolio, date: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold opacity-40 font-cute">카테고리</label>
                  <select 
                    className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                    value={newPortfolio.category}
                    onChange={(e) => setNewPortfolio({...newPortfolio, category: e.target.value})}
                  >
                    <option value="Event">이벤트</option>
                    <option value="Collaboration">협업/공구</option>
                    <option value="Info">안내/공지</option>
                    <option value="Brand">브랜드</option>
                    <option value="Daily">마을 일상</option>
                  </select>
                </div>

                <div className="pt-8">
                  <button 
                    type="submit" 
                    className="w-full py-6 bg-brand-dark text-brand-cream rounded-full text-sm font-bold hover:bg-brand-accent transition-all transform hover:scale-[1.02] shadow-xl"
                  >
                    기록 보관하기 ✨
                  </button>
                </div>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Add Resident Modal */}
      <AnimatePresence>
        {isAddResidentModalOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddResidentModalOpen(false)}
              className="fixed inset-0 bg-brand-dark/60 backdrop-blur-md z-[80]"
            />
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="fixed inset-4 md:inset-x-[25%] md:inset-y-[10%] bg-brand-cream z-[90] rounded-[3rem] overflow-hidden shadow-2xl flex flex-col"
            >
              <div className="p-10 border-b border-brand-dark/10 flex justify-between items-center">
                <h3 className="text-3xl font-serif">새 주민 입주 상담</h3>
                <button onClick={() => setIsAddResidentModalOpen(false)} className="p-2 hover:bg-brand-dark/5 rounded-full">
                  <X size={24} />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-10 md:p-16">
                <form onSubmit={handleAddResident} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <label className="text-xs font-bold opacity-40 font-cute">닉네임</label>
                      <input 
                        required
                        type="text" 
                        placeholder="예: 헤니 (Henny)"
                        className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                        value={newResident.name}
                        onChange={(e) => setNewResident({...newResident, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold opacity-40 font-cute">역할</label>
                      <input 
                        required
                        type="text" 
                        placeholder="예: 무해한 귀여움 추구"
                        className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                        value={newResident.role}
                        onChange={(e) => setNewResident({...newResident, role: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold opacity-40 font-cute">주요 분야</label>
                    <input 
                      required
                      type="text" 
                      placeholder="예: 큐트 & 데일리 메이크업"
                      className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                      value={newResident.specialty}
                      onChange={(e) => setNewResident({...newResident, specialty: e.target.value})}
                    />
                  </div>

                  <div className="space-y-4">
                    <label className="text-xs font-bold opacity-40 font-cute">주민 사진 (파일 업로드 or 이미지 붙여넣기)</label>
                    <div 
                      onPaste={handlePaste}
                      className="relative w-full aspect-[3/4] border-2 border-dashed border-brand-dark/10 rounded-3xl flex flex-col items-center justify-center gap-4 bg-white/50 group overflow-hidden"
                    >
                      {newResident.image ? (
                        <>
                          <img src={newResident.image} className="w-full h-full object-cover" alt="Preview" />
                          <button 
                            type="button"
                            onClick={() => setNewResident({...newResident, image: ""})}
                            className="absolute top-4 right-4 bg-brand-dark text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X size={16} />
                          </button>
                        </>
                      ) : (
                        <div className="text-center p-8">
                          <div className="mb-4 text-brand-dark/20 flex justify-center">
                            <span className="material-symbols-outlined text-4xl">Image</span>
                          </div>
                          <p className="text-xs font-bold mb-4 opacity-40 leading-relaxed font-cute">
                            파일을 선택하거나 <br /> 이미지를 복사해서 붙여넣어주세요!
                          </p>
                          <input 
                            type="file" 
                            accept="image/*"
                            onChange={(e) => e.target.files && handleImageFile(e.target.files[0])}
                            className="hidden" 
                            id="resident-image-upload"
                          />
                          <label 
                            htmlFor="resident-image-upload"
                            className="px-6 py-2 bg-brand-dark text-brand-cream text-[10px] font-bold rounded-full cursor-pointer hover:bg-brand-accent transition-colors"
                          >
                            파일 선택기 열기
                          </label>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold opacity-40 font-cute">한줄 소개</label>
                    <textarea 
                      required
                      rows={2}
                      placeholder="주민을 소개하는 글을 써주세요"
                      className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors resize-none"
                      value={newResident.bio}
                      onChange={(e) => setNewResident({...newResident, bio: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold opacity-40 font-cute">키워드 (쉼표로 구분)</label>
                    <input 
                      type="text" 
                      placeholder="예: #무해함, #큐트, #데일리"
                      className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                      onChange={(e) => setNewResident({...newResident, keywords: e.target.value.split(",").map(k => k.trim())})}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold opacity-40 font-cute">협업 조건</label>
                    <input 
                      type="text" 
                      placeholder="예: 장기 브랜드 파트너십 선호"
                      className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                      value={newResident.collaborationCondition}
                      onChange={(e) => setNewResident({...newResident, collaborationCondition: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold opacity-40 font-cute text-brand-accent italic">본인 확인 비밀번호 (편집/삭제용)</label>
                    <input 
                      required
                      type="password" 
                      placeholder="본인만 아는 비밀번호를 설정해주세요"
                      className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors"
                      value={newResident.password}
                      onChange={(e) => setNewResident({...newResident, password: e.target.value})}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                    <div className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold opacity-40 font-cute">Instagram</label>
                        <input 
                          type="text" 
                          placeholder="@username"
                          className="w-full bg-transparent border-b border-brand-dark/20 py-2 outline-none focus:border-brand-accent transition-colors text-sm"
                          onChange={(e) => setNewResident({...newResident, socials: {...newResident.socials, instagram: e.target.value}})}
                        />
                        <input 
                          type="text" 
                          placeholder="프로필 링크 (https://...)"
                          className="w-full bg-transparent border-b border-brand-dark/10 py-1 outline-none focus:border-brand-accent transition-colors text-[10px]"
                          onChange={(e) => setNewResident({...newResident, socialLinks: {...newResident.socialLinks, instagram: e.target.value}})}
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold opacity-40 font-cute">YouTube</label>
                        <input 
                          type="text" 
                          placeholder="채널명"
                          className="w-full bg-transparent border-b border-brand-dark/20 py-2 outline-none focus:border-brand-accent transition-colors text-sm"
                          onChange={(e) => setNewResident({...newResident, socials: {...newResident.socials, youtube: e.target.value}})}
                        />
                        <input 
                          type="text" 
                          placeholder="채널 링크 (https://...)"
                          className="w-full bg-transparent border-b border-brand-dark/10 py-1 outline-none focus:border-brand-accent transition-colors text-[10px]"
                          onChange={(e) => setNewResident({...newResident, socialLinks: {...newResident.socialLinks, youtube: e.target.value}})}
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold opacity-40 font-cute">TikTok</label>
                        <input 
                          type="text" 
                          placeholder="@username"
                          className="w-full bg-transparent border-b border-brand-dark/20 py-2 outline-none focus:border-brand-accent transition-colors text-sm"
                          onChange={(e) => setNewResident({...newResident, socials: {...newResident.socials, tiktok: e.target.value}})}
                        />
                        <input 
                          type="text" 
                          placeholder="프로필 링크 (https://...)"
                          className="w-full bg-transparent border-b border-brand-dark/10 py-1 outline-none focus:border-brand-accent transition-colors text-[10px]"
                          onChange={(e) => setNewResident({...newResident, socialLinks: {...newResident.socialLinks, tiktok: e.target.value}})}
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold opacity-40 font-cute">Threads</label>
                        <input 
                          type="text" 
                          placeholder="@username"
                          className="w-full bg-transparent border-b border-brand-dark/20 py-2 outline-none focus:border-brand-accent transition-colors text-sm"
                          onChange={(e) => setNewResident({...newResident, socials: {...newResident.socials, threads: e.target.value}})}
                        />
                        <input 
                          type="text" 
                          placeholder="프로필 링크 (https://...)"
                          className="w-full bg-transparent border-b border-brand-dark/10 py-1 outline-none focus:border-brand-accent transition-colors text-[10px]"
                          onChange={(e) => setNewResident({...newResident, socialLinks: {...newResident.socialLinks, threads: e.target.value}})}
                        />
                      </div>
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-6 bg-brand-dark text-brand-cream font-bold text-lg hover:bg-brand-accent transition-all rounded-full font-cute"
                  >
                    입주 완료하기! ✨
                  </button>
                </form>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Password Verification Modal */}
      <AnimatePresence>
        {isVerifyModalOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsVerifyModalOpen(false)}
              className="fixed inset-0 bg-brand-dark/80 backdrop-blur-md z-[100]"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md bg-brand-cream z-[110] p-10 rounded-[2.5rem] shadow-2xl"
            >
              <h3 className="text-2xl font-serif mb-2">권한 확인</h3>
              <p className="text-sm text-brand-dark/60 mb-8 font-cute">
                {verifyAction === "admin" ? "관리자 모드 진입" : (verifyAction === "delete" ? "삭제" : "편집")}를 위해 비밀번호를 입력해주세요. <br />
                <span className="text-[10px] opacity-40">
                  {verifyAction === "admin" 
                    ? "(관리자 전용)" 
                    : "(관리자 비밀번호 또는 입주시 설정한 비밀번호)"}
                </span>
              </p>
              
              <form onSubmit={handleVerifyPassword} className="space-y-6">
                <input 
                  autoFocus
                  required
                  type="password" 
                  placeholder="비밀번호 입력"
                  className="w-full bg-transparent border-b border-brand-dark/20 py-4 outline-none focus:border-brand-accent transition-colors text-center font-bold"
                  value={verifyPassword}
                  onChange={(e) => setVerifyPassword(e.target.value)}
                />
                
                <div className="flex gap-4">
                  <button 
                    type="button"
                    onClick={() => setIsVerifyModalOpen(false)}
                    className="flex-1 py-4 border border-brand-dark/10 rounded-full text-xs font-bold hover:bg-brand-dark/5 transition-all font-cute"
                  >
                    취소
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-4 bg-brand-dark text-brand-cream rounded-full text-xs font-bold hover:bg-brand-accent transition-all font-cute text-lg"
                  >
                    확인
                  </button>
                </div>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Inquiry Form Section */}
      <section id="contact" className="py-32 px-8 bg-brand-dark text-brand-cream relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-accent/5 skew-x-12 pointer-events-none" />
        
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-24 relative z-10">
          <div className="lg:w-2/5">
            <h2 className="text-5xl md:text-[80px] font-serif mb-12 tracking-tight">
              함께 <br />북적북적해요!
            </h2>
            <p className="text-brand-cream/60 leading-relaxed mb-12 italic">
              브랜드 협업, 광고 문의, 프로젝트 제안 등 <br />
              코덕마을은 언제나 새로운 만남을 기다리고 있습니다.
            </p>
            
            <div className="space-y-6 pt-12 border-t border-brand-cream/10">
              <div className="flex items-center gap-6">
                <div className="w-12 h-12 rounded-full border border-brand-cream/20 flex items-center justify-center">
                  <Mail size={18} />
                </div>
                <div>
                  <div className="text-[10px] opacity-40 mb-1">Email</div>
                  <div className="font-bold">henny0321@naver.com</div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-3/5 bg-white/5 backdrop-blur-xl p-10 md:p-16 rounded-[3rem] border border-white/10">
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-xs font-bold opacity-40 font-cute">이름</label>
                  <input 
                    required
                    type="text" 
                    placeholder="성함을 입력해주세요"
                    className="w-full bg-transparent border-b border-brand-cream/20 py-4 outline-none focus:border-brand-accent transition-colors"
                    value={formState.name}
                    onChange={(e) => setFormState({...formState, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold opacity-40 font-cute">이메일 주소</label>
                  <input 
                    required
                    type="email" 
                    placeholder="이메일을 입력해주세요"
                    className="w-full bg-transparent border-b border-brand-cream/20 py-4 outline-none focus:border-brand-accent transition-colors"
                    value={formState.email}
                    onChange={(e) => setFormState({...formState, email: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold opacity-40 font-cute">소속 / 회사명</label>
                <input 
                  type="text" 
                  placeholder="회사명을 입력해주세요"
                  className="w-full bg-transparent border-b border-brand-cream/20 py-4 outline-none focus:border-brand-accent transition-colors"
                  value={formState.company}
                  onChange={(e) => setFormState({...formState, company: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold opacity-40 font-cute">문의 내용</label>
                <textarea 
                  required
                  rows={4}
                  placeholder="문의 내용을 입력해주세요"
                  className="w-full bg-transparent border-b border-brand-cream/20 py-4 outline-none focus:border-brand-accent transition-colors resize-none"
                  value={formState.content}
                  onChange={(e) => setFormState({...formState, content: e.target.value})}
                />
              </div>
              
              <button 
                type="submit"
                className="w-full py-6 bg-brand-accent text-brand-dark font-bold text-lg hover:bg-white hover:text-brand-dark transition-all rounded-full flex items-center justify-center gap-3 group font-cute"
              >
                문의 보내기 <Send size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-8 bg-brand-cream text-brand-dark border-t border-brand-dark/5 text-center relative">
        <div className="text-xl font-serif font-bold italic mb-6">코덕마을</div>
        <div className="text-[10px] opacity-40 font-cute mb-10">
          &copy; 2024 Koduk Village Archive. All Rights Reserved.
        </div>
        
        {/* Admin Toggle in Footer */}
        <div className="pt-8 border-t border-brand-dark/5 max-w-xs mx-auto">
          <button 
            onClick={toggleAdminMode}
            className={`text-[9px] font-bold tracking-widest uppercase px-4 py-2 rounded-full transition-all ${
              isAdminMode 
                ? "bg-brand-accent/20 text-brand-accent" 
                : "text-brand-dark/20 hover:text-brand-dark/40"
            }`}
          >
            {isAdminMode ? "Admin Access Enabled" : "Admin Access"}
          </button>
        </div>
      </footer>
    </div>
  );
}

